import React from 'react'

function CreateTask({TaskView}) {
  console.log("TaskView----------------------", TaskView);
  return (
    
    // TaskView.map((showTask,i) => {
    //   <div key={showTask.Name}>
    //       <p>{showTask.Name}</p> 
    //   </div>
    // })

    <div>Welcome</div>
    
  )
}

export default CreateTask

